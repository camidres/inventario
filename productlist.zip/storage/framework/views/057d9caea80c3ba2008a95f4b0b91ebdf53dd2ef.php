<div>

    <div x-data="{ open: false }">
        <button class="block lg:hidden py-2 px-4 bg-gray-300 absolute" @click="open = !open">
            <i class="fas fa-bars"></i>
        </button>
     
        <nav x-show="open" @click.away="open = false">
            <div class="fixed bg-gray-700 h-screen w-64 z-50">
                <div class="flex py-20 px-4  text-white ">

                    <i class="fas fa-shop text-5xl"></i>
                    <p class="text-lg font-semibold mt-5 ml-2">
                        Mi inventario
                    </p>
        
                </div>
        
        
        
                <div class="mt-10">
                    <a href="<?php echo e(route('show.products')); ?>">
                        <div class="flex items-center py-4 px-4 w-full hover:bg-gray-500">
                            <i class="fas fa-basket-shopping text-white"></i>
                            <p class="ml-2 text-white cursor-pointer text-md font-semibold ">
                                Productos
                            </p>
        
                        </div>
                    </a>
        
                    <a href="<?php echo e(route('show.sales')); ?>">
                        <div class="flex items-center py-4 px-4 w-full hover:bg-gray-500">
        
                            <i class="fas fa-money-bill-1 text-white"></i>
                            <p class="ml-2 text-white cursor-pointer text-md font-semibold ">
                                Ventas
                            </p>
        
                        </div>
                    </a>
        
                    <a href="<?php echo e(route('show.shoppings')); ?>">
                        <div class="flex items-center py-4 px-4 w-full hover:bg-gray-500">
        
                            <i class="fas fa-sack-dollar text-white"></i>
                            <p class="ml-2 text-white cursor-pointer text-md font-semibold ">
                                Compras
                            </p>
        
                        </div>
                    </a>
        
        
                </div>
        
                <div class="py-4 px-4 mt-36">
        
                    <form method="POST" action="<?php echo e(route('logout')); ?>" x-data>
                        <?php echo csrf_field(); ?>
        
                        <div class="flex items-center">
                            <p class="text-white mr-2 cursor-pointer text-md font-semibold" href="<?php echo e(route('logout')); ?>"
                                @click.prevent="$root.submit();">
        
                                <?php echo e(__('Cerrar sesion')); ?>

                            </p>
        
                            <i class="fas fa-right-from-bracket text-white"></i>
                        </div>
        
                    </form>
        
                </div>
            </div>
        </nav>
    </div>


    <div class="fixed bg-gray-700 h-screen w-64 z-50 hidden lg:block">



        <div class="flex py-20 px-4  text-white ">

            <i class="fas fa-shop text-5xl"></i>
            <p class="text-lg font-semibold mt-5 ml-2">
                Mi inventario
            </p>

        </div>



        <div class="mt-10">
            <a href="<?php echo e(route('show.products')); ?>">
                <div class="flex items-center py-4 px-4 w-full hover:bg-gray-500">
                    <i class="fas fa-basket-shopping text-white"></i>
                    <p class="ml-2 text-white cursor-pointer text-md font-semibold ">
                        Productos
                    </p>

                </div>
            </a>

            <a href="<?php echo e(route('show.sales')); ?>">
                <div class="flex items-center py-4 px-4 w-full hover:bg-gray-500">

                    <i class="fas fa-money-bill-1 text-white"></i>
                    <p class="ml-2 text-white cursor-pointer text-md font-semibold ">
                        Ventas
                    </p>

                </div>
            </a>

            <a href="<?php echo e(route('show.shoppings')); ?>">
                <div class="flex items-center py-4 px-4 w-full hover:bg-gray-500">

                    <i class="fas fa-sack-dollar text-white"></i>
                    <p class="ml-2 text-white cursor-pointer text-md font-semibold ">
                        Compras
                    </p>

                </div>
            </a>


        </div>

        <div class="py-4 px-4 mt-36">

            <form method="POST" action="<?php echo e(route('logout')); ?>" x-data>
                <?php echo csrf_field(); ?>

                <div class="flex items-center">
                    <p class="text-white mr-2 cursor-pointer text-md font-semibold" href="<?php echo e(route('logout')); ?>"
                        @click.prevent="$root.submit();">

                        <?php echo e(__('Cerrar sesion')); ?>

                    </p>

                    <i class="fas fa-right-from-bracket text-white"></i>
                </div>

            </form>

        </div>

    </div>



</div>
<?php /**PATH C:\xampp\htdocs\productlist\resources\views/navigation-menu.blade.php ENDPATH**/ ?>