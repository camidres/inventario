<div>



    <div class=" flex flex-col w-full lg:pl-64 lg:h-screen ">
        <div class="container py-16 lg:py-10">

            <div class="py-2 text-lg font-semibold">
                <p>
                    Lista de productos
                </p>
            </div>


            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

                <div class="px-6 py-4 flex items-center bg-gray-100">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['class' => 'flex-1 mr-3 ml-2','placeholder' => 'Ingresa el producto a buscar','type' => 'text','wire:model' => 'search']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'flex-1 mr-3 ml-2','placeholder' => 'Ingresa el producto a buscar','type' => 'text','wire:model' => 'search']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('product-create')->html();
} elseif ($_instance->childHasBeenRendered('l1386497645-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1386497645-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1386497645-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1386497645-0');
} else {
    $response = \Livewire\Livewire::mount('product-create');
    $html = $response->html();
    $_instance->logRenderedChild('l1386497645-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>


                <?php if($products->count()): ?>


                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">

                            <tr>
                                <th scope="col"
                                    class="px-6 py-3 text-left text-xs font-medium cursor-pointer text-gray-500 uppercase tracking-wider"
                                    wire:click="order('id')">

                                    ID
                                    <?php if($sort == 'id'): ?>

                                        <?php if($direction == 'asc'): ?>
                                            <i class="fas fa-sort-alpha-up float-right"></i>
                                        <?php else: ?>
                                            <i class="fas fa-sort-alpha-down float-right"></i>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <i class="fas fa-sort flex float-right"></i>
                                    <?php endif; ?>
                                </th>

                                <th scope="col"
                                    class="px-6 py-3 text-left text-xs font-medium cursor-pointer text-gray-500 uppercase tracking-wider">

                                    Nombre

                                </th>

                                <th scope="col"
                                    class="px-6 py-3 text-left text-xs font-medium cursor-pointer text-gray-500 uppercase tracking-wider">

                                    Precio

                                </th>

                                <th scope="col" class="relative px-6 py-3">

                                </th>
                            </tr>

                        </thead>

                        <tbody class="bg-white divide-y divide-gray-200">

                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>

                                    <td class=" px-6 py-4 ">
                                        <div class="text-sm  text-gray-900">
                                            <?php echo e($product->id); ?>

                                        </div>

                                    </td>

                                    <td class="px-6 py-4">


                                        <div class="text-sm  text-gray-900">
                                            <?php echo e($product->name); ?>

                                        </div>

                                    </td>





                                    <td class="px-6 py-4 ">


                                        <div class="text-sm  text-gray-900">
                                            <?php echo e($product->price); ?>

                                        </div>

                                    </td>

                                    <td class="flex justify-end px-6 py-4   ">



                                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('product-edit', ['product' => $product])->html();
} elseif ($_instance->childHasBeenRendered($product->id)) {
    $componentId = $_instance->getRenderedChildComponentId($product->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($product->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($product->id);
} else {
    $response = \Livewire\Livewire::mount('product-edit', ['product' => $product]);
    $html = $response->html();
    $_instance->logRenderedChild($product->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


                                        <div>
                                            <a class="btn btn-red ml-2"
                                                wire:click="$emit('deleteProduct', <?php echo e($product->id); ?>)">
                                                <i class="fas fa-trash "></i>
                                            </a>
                                        </div>


                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="px-6 py-4 text-center bg-white">

                        No existe ningun registro coincidente.

                    </div>

                <?php endif; ?>

                <?php if($products->hasPages()): ?>
                    <div class="py-4 px-3">
                        <?php echo e($products->links()); ?>

                    </div>
                <?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

           
        </div>
    </div>




    <?php $__env->startPush('js'); ?>
        <script>
            Livewire.on('deleteProduct', productId => {


                Swal.fire({
                    title: '¿Estas seguro de eliminar el producto?',
                    text: "Esta accion no tiene reverza!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Si, eliminar!'
                }).then((result) => {
                    if (result.isConfirmed) {

                        Livewire.emitTo('products-show', 'delete', productId)

                        Swal.fire(
                            'Eliminado',
                            'El producto ha sido eliminado',
                            'success'
                        )
                    }
                })

            })
        </script>
    <?php $__env->stopPush(); ?>

</div>
<?php /**PATH C:\xampp\htdocs\productlist\resources\views/livewire/products-show.blade.php ENDPATH**/ ?>