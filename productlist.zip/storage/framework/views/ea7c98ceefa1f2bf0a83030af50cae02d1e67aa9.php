<div>
    <a class="btn btn-blue" wire:click="$set('open', true)">
        <i class="fas fa-eye "></i>
    </a>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dialog-modal','data' => ['wire:model' => 'open']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'open']); ?>

         <?php $__env->slot('title', null, []); ?> 
            Detalle de venta
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('content', null, []); ?> 

            <div class="mb-8   ">

                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <table class="min-w-full divide-y divide-gray-200 ">
                        <thead class="bg-gray-50">
                            <tr>
                                <th scope="col"
                                    class="px-6 py-3 text-center text-md font-medium 
                                    cursor-pointer text-gray-500 uppercase 
                                    tracking-wider">

                                    Nombre

                                </th>


                                <th scope="col"
                                    class="px-6 py-3 text-center text-md font-medium 
                                cursor-pointer text-gray-500 uppercase 
                                tracking-wider">

                                    Precio

                                </th>


                                <th scope="col"
                                    class="px-6 py-3 text-center text-md font-medium 
                            cursor-pointer text-gray-500 uppercase 
                            tracking-wider">

                                    Cantidad

                                </th>


                            </tr>
                        </thead>

                        <tbody class="bg-white divide-y divide-gray-200 ">

                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="px-6 py-4">
                                        <div class="text-sm text-center text-gray-900">
                                            <?php echo e($item->name); ?>

                                        </div>
                                    </td>

                                    <td class="px-6 py-4">
                                        <div class="text-sm text-center text-gray-900">
                                            <?php echo e($item->price); ?>

                                        </div>
                                    </td>

                                    <td class="px-6 py-4">
                                        <div class="text-sm text-center text-gray-900">
                                            <?php echo e($item->qty); ?>

                                        </div>
                                    </td>


                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>


            </div>

            <div class="bg-white rounded-lg shadow-lg px-6 py-4 mt-4">

                <div class="flex justify-between">

                    <div>
                        
                            <p class="text-gray-700">
                                <span class="font-bold text-lg">Total:</span>

                                $ <?php echo e(number_format($sale->total)); ?>

                            </p>
                      
                    </div>



                </div>

            </div>

         <?php $__env->endSlot(); ?>

         <?php $__env->slot('footer', null, []); ?> 


         <?php $__env->endSlot(); ?>


     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\productlist\resources\views/livewire/sales-detail.blade.php ENDPATH**/ ?>