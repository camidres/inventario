<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\product;
use App\Models\sales;
use Carbon\Carbon;
use Gloudemans\Shoppingcart\Facades\Cart;

class SalesCreate extends Component
{
    public $product;
    public $qty;
    public $price;

    protected $rules = [

        'product'   => 'required',
        'price'     => 'required',
        'qty'       => 'required',
        'total'     => 'required'

    ];
    
    public function updatedProduct($value){

        $products = product::where('name',$value)->first();

        $this->price = $products->price;
    }


    

    public function render()
    {
   
        $products = product::all();
        
        return view('livewire.sales-create', compact('products'));
    }

    public function addItem(){

        Cart::add([
            'id' => rand(), 
            'name' =>$this->product, 
            'qty' => $this->qty, 
            'price' => $this->price
        ]);

    }

    public function delete($rowId){
        
        Cart::remove($rowId);
        
    }


    public function save(){

       

       $sales = new sales;

       $sales->content = Cart::content();
       $sales->total = str_replace(',', '', Cart::subtotal() ) ;

       $sales->save();

       Cart::destroy();

       return redirect()->route('show.sales');

    }
}
