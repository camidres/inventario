<?php

namespace App\Http\Livewire;

use App\Models\shoppings;
use Livewire\Component;

class ShoppingCreate extends Component
{
    
    public $open = false;
    public $content;
    public $total;

    protected $rules = [

        'content'      => 'required',
        'total'  => 'required'
     
    ];


    public function render()
    {
        return view('livewire.shopping-create');
    }

    public function save(){

        $this->validate();

       shoppings::create([

            'content'      => $this->content,
            'total'  => $this->total,
          
        ]);

        $this->reset(['open', 'content', 'total']);
        $this->emitTo('shopping-show', 'render');
        $this->emit('alert', 'Compra registrada');

    }
}
