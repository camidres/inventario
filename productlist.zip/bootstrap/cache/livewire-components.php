<?php return array (
  'product-create' => 'App\\Http\\Livewire\\ProductCreate',
  'product-edit' => 'App\\Http\\Livewire\\ProductEdit',
  'products-show' => 'App\\Http\\Livewire\\ProductsShow',
  'sales-create' => 'App\\Http\\Livewire\\SalesCreate',
  'sales-detail' => 'App\\Http\\Livewire\\SalesDetail',
  'sales-edit' => 'App\\Http\\Livewire\\SalesEdit',
  'shopping-create' => 'App\\Http\\Livewire\\ShoppingCreate',
  'shopping-edit' => 'App\\Http\\Livewire\\ShoppingEdit',
  'shopping-show' => 'App\\Http\\Livewire\\ShoppingShow',
  'show-sales' => 'App\\Http\\Livewire\\ShowSales',
);